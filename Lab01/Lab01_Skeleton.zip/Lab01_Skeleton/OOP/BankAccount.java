import java.util.ArrayList;
import java.util.List;


// BankAccount Class
public class BankAccount {
    // Attributes
    private final int accountNumber; 
	private final String owner;
	private double balance;

    // Constructor
    public BankAccount(int accountNumber, String owner, double balance) {
        this.accountNumber = accountNumber;
        this.owner = owner;
        this.balance = balance;
    }

    // Operation: Deposit
    public void deposit(double amount) {
        // TODO : Add amount to balance, print success/failure message
    }

    // Operation: Withdraw
    public void withdraw(double amount) {
        // TODO : Subtract amount from balance if sufficient, print messages
    }

    // Operation: Show Balance
    public void showBalance() {
        // TODO : Print account number, owner, and current balance
    }
    
    // Getter for account number
    public int getAccountNumber() {
        // TODO : Return the variable used by BankApp for searching
    }
}