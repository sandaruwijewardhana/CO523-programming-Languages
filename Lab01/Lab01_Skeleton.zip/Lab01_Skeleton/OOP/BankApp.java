import java.util.ArrayList;
import java.util.List;


public class BankApp {
    // Stores accounts using a List
    private static List<BankAccount> accounts = new ArrayList<>();

    // --- Helper Method to find account using Linear Search ---
    private static BankAccount findAccount(int accountNumber) {
        for (BankAccount account : accounts) {
            if (account.getAccountNumber() == accountNumber) {
                return account;
            }
        }
        return null;
    }

    // Function to create and add an account
    public static BankAccount createAccount(int accountNumber, String owner, double balance) {
        // TODO
        // 1. Check if account already exists using findAccount.
        // 2. If not, create a new BankAccount object and add it to the 'accounts' list.
    }

    // Function to handle deposit
    public static void deposit(int accountNumber, double amount) {
        // TODO 
    }

    // Function to handle withdrawal
    public static void withdraw(int accountNumber, double amount) {
        // TODO
    }

    // Function to show balance
    public static void showBalance(int accountNumber) {
        // TODO
    }
	
// Main Method
    public static void main(String[] args) {
        // --- Code from user request starts here ---
        System.out.println("--- Starting Bank System (Default Package) ---");
        
        createAccount(101, "Ruwan", 1000.00);
        createAccount(102, "Nimal", 500.00);
        
        System.out.println("--- Transactions ---");
        
        deposit(101, 300.00);
        withdraw(102, 100.00);
        
        System.out.println("--- Final Balances ---");

        showBalance(101);
        showBalance(102);
        showBalance(999); 
    }
}