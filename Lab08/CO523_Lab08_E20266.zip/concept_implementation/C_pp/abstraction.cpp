#include <iostream>
#include <string>

class Employee {
public:
    std::string name;
    int id;
    double salary;

    virtual void work() const = 0;

    void displayInfo() const {
        std::cout << "Name: " << name << ", Salary: $" << salary << '\n';
    }

    virtual ~Employee() = default;
};

class Developer : public Employee {
public:
    void work() const override {
        std::cout << name << " is writing code." << '\n';
    }
};

class Manager : public Employee {
public:
    void work() const override {
        std::cout << name << " is managing the team." << '\n';
    }
};

int main() {
    Developer dev;
    dev.name = "Tom";
    dev.id = 2157;
    dev.salary = 60000;
    dev.displayInfo();
    dev.work();

    Manager mgr;
    mgr.name = "Billy";
    mgr.id = 3015;
    mgr.salary = 85000;
    mgr.displayInfo();
    mgr.work();

    return 0;
}
