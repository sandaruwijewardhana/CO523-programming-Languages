#include <iostream>
#include <string>

class Employee {
public:
    std::string name;
    int id;
    double salary;

    void work() const {
        std::cout << name << " is working..." << '\n';
    }

    void work(const std::string& project) const {
        std::cout << name << " is working on project: " << project << '\n';
    }
};

int main() {
    Employee emp;
    emp.name = "Jeorge";
    emp.id = 1452;
    emp.salary = 71000;

    emp.work();
    emp.work("Website Redesign");

    return 0;
}
