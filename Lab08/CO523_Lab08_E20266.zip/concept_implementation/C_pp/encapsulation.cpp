#include <iostream>
#include <string>

class Employee {
private:
    std::string name;
    int id;
    double salary;

public:
    void setName(const std::string& n) { name = n; }
    void setId(int i) { id = i; }
    void setSalary(double s) { salary = s; }

    std::string getName() const { return name; }
    int getId() const { return id; }
    double getSalary() const { return salary; }

    void displayInfo() const {
        std::cout << "Name: " << name << ", Salary: $" << salary << '\n';
    }

    void work() const {
        std::cout << name << " is working..." << '\n';
    }
};

int main() {
    Employee emp;
    emp.setName("Alice");
    emp.setId(101);
    emp.setSalary(50000.0);

    emp.displayInfo();
    emp.work();
    std::cout << "Employee Name: " << emp.getName() << '\n';
    std::cout << "Employee Salary: $" << emp.getSalary() << '\n';
    return 0;
}
