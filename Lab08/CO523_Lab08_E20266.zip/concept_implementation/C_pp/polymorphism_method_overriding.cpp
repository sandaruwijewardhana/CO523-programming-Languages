#include <iostream>
#include <string>

class Employee {
public:
    std::string name;
    int id;
    double salary;

    virtual void work() const {
        std::cout << name << " is working..." << '\n';
    }

    virtual ~Employee() = default;
};

class Developer : public Employee {
public:
    void work() const override {
        std::cout << name << " is writing code." << '\n';
    }
};

int main() {
    Developer dev;
    dev.name = "John";
    dev.id = 3287;
    dev.salary = 65000;
    dev.work();
    return 0;
}
