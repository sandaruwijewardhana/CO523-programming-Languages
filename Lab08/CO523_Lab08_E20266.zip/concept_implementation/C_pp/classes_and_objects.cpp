#include <iostream>
#include <string>

class Employee {
public:
    std::string name;
    int id;
    double salary;

    void displayInfo() const {
        std::cout << "Name: " << name << ", Salary: $" << salary << '\n';
    }

    void work() const {
        std::cout << name << " is working..." << '\n';
    }
};

int main() {
    Employee emp;
    emp.name = "Alice";
    emp.id = 101;
    emp.salary = 50000.0;

    emp.displayInfo();
    emp.work();
    std::cout << "Employee Name: " << emp.name << '\n';
    return 0;
}
