#include <iostream>
#include <string>

class Employee {
public:
    std::string name;
    int id;
    double salary;

    void displayInfo() const {
        std::cout << "Name: " << name << ", Salary: $" << salary << '\n';
    }

    virtual void work() const {
        std::cout << name << " is working..." << '\n';
    }

    virtual ~Employee() = default;
};

class Manager : public Employee {
public:
    double calculateBonus() const {
        return salary * 0.20;
    }
};

class Developer : public Employee {
public:
    double calculateBonus() const {
        return salary * 0.10;
    }
};

class Intern : public Employee {
public:
    void learn() const {
        std::cout << name << " is learning new skills." << '\n';
    }
};

int main() {
    Manager mgr;
    mgr.name = "Kevin";
    mgr.id = 1023;
    mgr.salary = 80000;
    mgr.displayInfo();
    mgr.work();
    std::cout << "Manager Bonus: $" << mgr.calculateBonus() << '\n';

    std::cout << '\n';

    Developer dev;
    dev.name = "Bob";
    dev.id = 1012;
    dev.salary = 60000;
    dev.displayInfo();
    dev.work();
    std::cout << "Developer Bonus: $" << dev.calculateBonus() << '\n';

    std::cout << '\n';

    Intern intern;
    intern.name = "Charlie";
    intern.id = 203;
    intern.salary = 20000;
    intern.displayInfo();
    intern.work();
    intern.learn();

    return 0;
}
