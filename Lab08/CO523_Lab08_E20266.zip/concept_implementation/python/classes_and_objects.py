class Employee:
    def __init__(self):
        self.name = ""
        self.id = 0
        self.salary = 0.0

    def display_info(self):
        print(f"Name: {self.name}, Salary: ${self.salary}")

    def work(self):
        print(f"{self.name} is working...")


def main():
    emp = Employee()
    emp.name = "Alice"
    emp.id = 101
    emp.salary = 50000.0

    emp.display_info()
    emp.work()
    print(f"Employee Name: {emp.name}")


if __name__ == "__main__":
    main()
