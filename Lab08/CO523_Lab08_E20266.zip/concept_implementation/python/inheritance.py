class Employee:
    def __init__(self):
        self.name = ""
        self.id = 0
        self.salary = 0.0

    def display_info(self):
        print(f"Name: {self.name}, Salary: ${self.salary}")

    def work(self):
        print(f"{self.name} is working...")


class Manager(Employee):
    def calculate_bonus(self):
        return self.salary * 0.20


class Developer(Employee):
    def calculate_bonus(self):
        return self.salary * 0.10


class Intern(Employee):
    def learn(self):
        print(f"{self.name} is learning new skills.")


def main():
    mgr = Manager()
    mgr.name = "Kevin"
    mgr.id = 1023
    mgr.salary = 80000
    mgr.display_info()
    mgr.work()
    print(f"Manager Bonus: ${mgr.calculate_bonus()}")

    print()

    dev = Developer()
    dev.name = "Bob"
    dev.id = 1012
    dev.salary = 60000
    dev.display_info()
    dev.work()
    print(f"Developer Bonus: ${dev.calculate_bonus()}")

    print()

    intern = Intern()
    intern.name = "Charlie"
    intern.id = 203
    intern.salary = 20000
    intern.display_info()
    intern.work()
    intern.learn()


if __name__ == "__main__":
    main()
