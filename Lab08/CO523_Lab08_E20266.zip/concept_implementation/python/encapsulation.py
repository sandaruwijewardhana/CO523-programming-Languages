class Employee:
    def __init__(self):
        self.__name = ""
        self.__id = 0
        self.__salary = 0.0

    def set_name(self, name):
        self.__name = name

    def set_id(self, emp_id):
        self.__id = emp_id

    def set_salary(self, salary):
        self.__salary = salary

    def get_name(self):
        return self.__name

    def get_id(self):
        return self.__id

    def get_salary(self):
        return self.__salary

    def display_info(self):
        print(f"Name: {self.__name}, Salary: ${self.__salary}")

    def work(self):
        print(f"{self.__name} is working...")


def main():
    emp = Employee()
    emp.set_name("Alice")
    emp.set_id(101)
    emp.set_salary(50000.0)

    emp.display_info()
    emp.work()
    print(f"Employee Name: {emp.get_name()}")
    print(f"Employee Salary: ${emp.get_salary()}")


if __name__ == "__main__":
    main()
