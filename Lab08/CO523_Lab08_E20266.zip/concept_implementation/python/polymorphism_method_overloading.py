class Employee:
    def __init__(self):
        self.name = ""
        self.id = 0
        self.salary = 0.0

    def work(self, project=None):
        if project is None:
            print(f"{self.name} is working...")
        else:
            print(f"{self.name} is working on project: {project}")


def main():
    emp = Employee()
    emp.name = "Jeorge"
    emp.id = 1452
    emp.salary = 71000

    emp.work()
    emp.work("Website Redesign")


if __name__ == "__main__":
    main()
