class Employee:
    def __init__(self):
        self.name = ""
        self.id = 0
        self.salary = 0.0

    def work(self):
        print(f"{self.name} is working...")


class Developer(Employee):
    def work(self):
        print(f"{self.name} is writing code.")


def main():
    dev = Developer()
    dev.name = "John"
    dev.id = 3287
    dev.salary = 65000

    dev.work()


if __name__ == "__main__":
    main()
