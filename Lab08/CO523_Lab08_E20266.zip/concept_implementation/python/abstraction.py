from abc import ABC, abstractmethod


class Employee(ABC):
    def __init__(self):
        self.name = ""
        self.id = 0
        self.salary = 0.0

    @abstractmethod
    def work(self):
        pass

    def display_info(self):
        print(f"Name: {self.name}, Salary: ${self.salary}")


class Developer(Employee):
    def work(self):
        print(f"{self.name} is writing code.")


class Manager(Employee):
    def work(self):
        print(f"{self.name} is managing the team.")


def main():
    dev = Developer()
    dev.name = "Tom"
    dev.id = 2157
    dev.salary = 60000

    dev.display_info()
    dev.work()

    mgr = Manager()
    mgr.name = "Billy"
    mgr.id = 3015
    mgr.salary = 85000

    mgr.display_info()
    mgr.work()


if __name__ == "__main__":
    main()
